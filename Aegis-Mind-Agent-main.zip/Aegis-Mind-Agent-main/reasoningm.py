import os
import json
import hashlib
from dotenv import load_dotenv
from typing import Annotated, Dict, Any, Optional
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph import add_messages
from langchain_groq import ChatGroq
from langchain.schema import HumanMessage
import pinecone
from pinecone import Pinecone
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from datetime import datetime
import pymongo
from pymongo import MongoClient
from bson import ObjectId

load_dotenv()

# Environment setup
os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API_KEY")
os.environ["LANGSMITH_API_KEY"] = os.getenv("LANGSMITH_API_KEY")
os.environ["LANGSMITH_PROJECT"] = os.getenv("LANGSMITH_PROJECT")
os.environ["LANGSMITH_ENDPOINT"] = os.getenv("LANGSMITH_ENDPOINT")
os.environ["LANGSMITH_TRACING"] = "true"

# MongoDB setup
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://arifcy7:IsJqcLtvA9ve2r71@aegismind.ziickgo.mongodb.net/")
MONGODB_DATABASE = os.getenv("MONGODB_DATABASE", "security_events")

# Initialize MongoDB
try:
    mongo_client = MongoClient(MONGODB_URI)
    db = mongo_client[MONGODB_DATABASE]
    
    # Collections
    events_collection = db.security_events
    analysis_collection = db.security_analysis
    
    # Test connection
    mongo_client.admin.command('ping')
    print("MongoDB connection successful!")
    
    # Create indexes for better performance
    events_collection.create_index([("event_id", 1)], unique=True)
    events_collection.create_index([("timestamp", -1)])
    events_collection.create_index([("source_ip", 1)])
    events_collection.create_index([("event_type", 1)])
    
    analysis_collection.create_index([("event_id", 1)])
    analysis_collection.create_index([("analysis_timestamp", -1)])
    analysis_collection.create_index([("urgency", 1)])
    
    print("MongoDB indexes created successfully!")
    
except Exception as e:
    print(f"MongoDB connection error: {e}")
    raise

# Initialize Pinecone
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT", "us-east-1")
INDEX_NAME = "security-events"

pc = Pinecone(api_key=PINECONE_API_KEY)

# Check if index exists and get its dimension
try:
    index = pc.Index(INDEX_NAME)
    # Get index stats to determine the actual dimension
    stats = index.describe_index_stats()
    VECTOR_DIMENSION = 1024  # Based on your error, the index expects 1024 dimensions
    print(f"Using existing index with {VECTOR_DIMENSION} dimensions")
except Exception as e:
    print(f"Index access error: {e}")
    # Create index with correct dimension if it doesn't exist
    VECTOR_DIMENSION = 1024
    try:
        pc.create_index(
            name=INDEX_NAME,
            dimension=VECTOR_DIMENSION,
            metric='cosine'
        )
        index = pc.Index(INDEX_NAME)
        print(f"Created new index with {VECTOR_DIMENSION} dimensions")
    except Exception as create_error:
        print(f"Failed to create index: {create_error}")
        raise

llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0)

# Prompt template
prompt_template = '''Instructions:
1. Assess whether the event constitutes a true {event_type_prompt}, based on the available evidence.
2. Explain your reasoning using observed event patterns, anomaly and confidence scores, asset criticality, and historical events.
3. Recommend the next best actions to mitigate or investigate the potential threat.
4. Assign an urgency level: Low, Medium, or High.

Event Data:
{event_data}

Output format:
Respond strictly in the following JSON format:

{{
  "attack_confirmed": true/false,
  "reasoning": "Your detailed explanation.",
  "recommended_actions": [
    "List of actionable recommendations"
  ],
  "urgency": "Low/Medium/High"
}}'''

class MongoDBManager:
    def __init__(self, events_collection, analysis_collection):
        self.events_collection = events_collection
        self.analysis_collection = analysis_collection
    
    def store_event(self, event_data: Dict[str, Any]) -> str:
        """Store security event in MongoDB"""
        try:
            # Create a unique event_id
            event_id = hashlib.md5(
                json.dumps(event_data, sort_keys=True).encode()
            ).hexdigest()
            
            # Add metadata
            document = {
                "event_id": event_id,
                "raw_event_data": event_data,
                "stored_timestamp": datetime.utcnow(),
                "event_type": event_data.get('event_type'),
                "source_ip": event_data.get('source_ip'),
                "destination": event_data.get('destination'),
                "username": event_data.get('username'),
                "timestamp": datetime.fromisoformat(event_data.get('timestamp', '').replace('Z', '+00:00')) if event_data.get('timestamp') else datetime.utcnow(),
                "success": event_data.get('success'),
                "failure_count": event_data.get('failure_count', 0),
                "anomaly_score": event_data.get('anomaly_score', 0.0),
                "detection_confidence": event_data.get('detection_confidence', 0.0),
                "asset_criticality": event_data.get('asset_criticality'),
                "status": "pending_analysis"
            }
            
            # Use upsert to avoid duplicates
            self.events_collection.replace_one(
                {"event_id": event_id},
                document,
                upsert=True
            )
            
            print(f"Stored event {event_id} in MongoDB")
            return event_id
            
        except Exception as e:
            print(f"Error storing event in MongoDB: {e}")
            return None
    
    def store_analysis(self, event_id: str, analysis_result: Dict[str, Any], source: str):
        """Store analysis result in MongoDB"""
        try:
            analysis_document = {
                "event_id": event_id,
                "analysis_result": analysis_result,
                "analysis_timestamp": datetime.utcnow(),
                "source": source,  # 'cache' or 'llm'
                "attack_confirmed": analysis_result.get('attack_confirmed'),
                "urgency": analysis_result.get('urgency'),
                "recommended_actions": analysis_result.get('recommended_actions', []),
                "reasoning": analysis_result.get('reasoning')
            }
            
            result = self.analysis_collection.insert_one(analysis_document)
            
            # Update the event status
            self.events_collection.update_one(
                {"event_id": event_id},
                {
                    "$set": {
                        "status": "analyzed",
                        "analysis_id": result.inserted_id,
                        "analyzed_timestamp": datetime.utcnow(),
                        "final_urgency": analysis_result.get('urgency'),
                        "attack_confirmed": analysis_result.get('attack_confirmed')
                    }
                }
            )
            
            print(f"Stored analysis for event {event_id} in MongoDB")
            return result.inserted_id
            
        except Exception as e:
            print(f"Error storing analysis in MongoDB: {e}")
            return None
    
    def get_similar_events(self, source_ip: str, event_type: str, limit: int = 5) -> list:
        """Retrieve similar events from MongoDB for historical context"""
        try:
            query = {
                "$or": [
                    {"source_ip": source_ip},
                    {"event_type": event_type}
                ],
                "status": "analyzed"
            }
            
            similar_events = list(
                self.events_collection.find(query)
                .sort("timestamp", -1)
                .limit(limit)
            )
            
            # Convert ObjectId to string for JSON serialization
            for event in similar_events:
                event['_id'] = str(event['_id'])
                if 'analysis_id' in event:
                    event['analysis_id'] = str(event['analysis_id'])
            
            return similar_events
            
        except Exception as e:
            print(f"Error retrieving similar events: {e}")
            return []
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get security event statistics from MongoDB"""
        try:
            total_events = self.events_collection.count_documents({})
            analyzed_events = self.events_collection.count_documents({"status": "analyzed"})
            
            # Urgency distribution
            urgency_pipeline = [
                {"$match": {"status": "analyzed"}},
                {"$group": {"_id": "$final_urgency", "count": {"$sum": 1}}}
            ]
            urgency_stats = list(self.events_collection.aggregate(urgency_pipeline))
            
            # Attack confirmation stats
            attack_stats = list(self.events_collection.aggregate([
                {"$match": {"status": "analyzed"}},
                {"$group": {"_id": "$attack_confirmed", "count": {"$sum": 1}}}
            ]))
            
            # Top source IPs
            top_ips = list(self.events_collection.aggregate([
                {"$group": {"_id": "$source_ip", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}},
                {"$limit": 10}
            ]))
            
            return {
                "total_events": total_events,
                "analyzed_events": analyzed_events,
                "pending_analysis": total_events - analyzed_events,
                "urgency_distribution": {item['_id']: item['count'] for item in urgency_stats},
                "attack_confirmation": {str(item['_id']): item['count'] for item in attack_stats},
                "top_source_ips": top_ips
            }
            
        except Exception as e:
            print(f"Error getting statistics: {e}")
            return {}

# Initialize MongoDB manager
mongo_manager = MongoDBManager(events_collection, analysis_collection)

class SecurityEventCache:
    def __init__(self, index, mongo_manager, vector_dimension=1024, similarity_threshold=0.85):
        self.index = index
        self.mongo_manager = mongo_manager
        self.vector_dimension = vector_dimension
        self.similarity_threshold = similarity_threshold
        # Use more features for better vectorization
        self.vectorizer = TfidfVectorizer(max_features=min(512, vector_dimension//2))
        
    def create_event_vector(self, event_data: Dict[str, Any]) -> np.ndarray:
        """Create a vector representation of the event for similarity matching"""
        # Create a more comprehensive text representation
        text_features = [
            event_data.get('event_type', ''),
            event_data.get('source_ip', ''),
            event_data.get('destination', ''),
            event_data.get('username', ''),
            str(event_data.get('failure_count', 0)),
            str(event_data.get('anomaly_score', 0)),
            event_data.get('asset_criticality', ''),
            event_data.get('user_agent', ''),
            str(event_data.get('detection_confidence', 0)),
            event_data.get('payload', '')[:100] if event_data.get('payload') else '',  # Truncate payload
        ]
        
        # Add historical events information
        if 'historical_events' in event_data and event_data['historical_events']:
            for hist_event in event_data['historical_events'][:3]:  # Limit to first 3 historical events
                text_features.extend([
                    hist_event.get('source_ip', ''),
                    str(hist_event.get('failure_count', 0))
                ])
        
        text_content = ' '.join(filter(None, text_features))
        
        try:
            # Try to transform first
            tfidf_vector = self.vectorizer.transform([text_content]).toarray()[0]
        except:
            # If not fitted yet, fit first then transform
            self.vectorizer.fit([text_content])
            tfidf_vector = self.vectorizer.transform([text_content]).toarray()[0]
        
        # Create additional numerical features
        numerical_features = np.array([
            event_data.get('failure_count', 0) / 100.0,  # Normalize
            event_data.get('anomaly_score', 0),
            event_data.get('detection_confidence', 0),
            len(event_data.get('historical_events', [])) / 10.0,  # Normalize count
            1.0 if event_data.get('asset_criticality') == 'high' else 0.5 if event_data.get('asset_criticality') == 'medium' else 0.0,
            1.0 if event_data.get('success', True) == False else 0.0,  # Failed login indicator
        ])
        
        # Combine TF-IDF and numerical features
        combined_features = np.concatenate([tfidf_vector, numerical_features])
        
        # Ensure the vector matches the required dimension
        if len(combined_features) < self.vector_dimension:
            # Pad with zeros
            vector = np.pad(combined_features, (0, self.vector_dimension - len(combined_features)))
        else:
            # Truncate to required dimension
            vector = combined_features[:self.vector_dimension]
            
        return vector.astype(np.float32)
    
    def create_event_hash(self, event_data: Dict[str, Any]) -> str:
        """Create a hash for the event to use as ID"""
        # Use key identifying features for the hash
        key_features = {
            'event_type': event_data.get('event_type'),
            'source_ip': event_data.get('source_ip'),
            'destination': event_data.get('destination'),
            'username': event_data.get('username'),
            'failure_count': event_data.get('failure_count'),
            'asset_criticality': event_data.get('asset_criticality')
        }
        
        event_string = json.dumps(key_features, sort_keys=True)
        return hashlib.md5(event_string.encode()).hexdigest()
    
    def search_similar_events(self, event_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Search for similar events in Pinecone"""
        try:
            vector = self.create_event_vector(event_data)
            print(f"Created vector with dimension: {len(vector)}")
            
            # Query Pinecone for similar vectors
            results = self.index.query(
                vector=vector.tolist(),
                top_k=1,
                include_metadata=True
            )
            
            if results.matches and results.matches[0].score >= self.similarity_threshold:
                return {
                    'cached_response': json.loads(results.matches[0].metadata['response']),
                    'similarity_score': results.matches[0].score,
                    'original_timestamp': results.matches[0].metadata['timestamp']
                }
            
            return None
            
        except Exception as e:
            print(f"Error searching similar events: {e}")
            return None
    
    def store_event_response(self, event_data: Dict[str, Any], response: str):
        """Store the event and its response in Pinecone"""
        try:
            vector = self.create_event_vector(event_data)
            event_id = self.create_event_hash(event_data)
            
            print(f"Storing vector with dimension: {len(vector)}")
            
            # Ensure metadata strings are not too long for Pinecone
            metadata = {
                'event_data': json.dumps(event_data)[:8000],  # Limit size
                'response': response[:8000],  # Limit size
                'timestamp': datetime.now().isoformat(),
                'event_type': event_data.get('event_type', '')[:100],
                'source_ip': event_data.get('source_ip', '')[:50],
                'username': event_data.get('username', '')[:100]
            }
            
            self.index.upsert([(event_id, vector.tolist(), metadata)])
            print(f"Successfully stored event {event_id} in Pinecone")
            
        except Exception as e:
            print(f"Error storing event: {e}")

class state_reasoning_agent(TypedDict):
    messages: Annotated[list, add_messages]
    event_data: Dict[str, Any]
    cached_response: Optional[Dict[str, Any]]
    event_id: Optional[str]

# Initialize cache with correct vector dimension and MongoDB manager
cache = SecurityEventCache(index, mongo_manager, vector_dimension=VECTOR_DIMENSION)

def store_event_node(state: state_reasoning_agent):
    """Store the initial event in MongoDB"""
    event_data = state['event_data']
    event_id = mongo_manager.store_event(event_data)
    
    # Enrich event data with similar events from MongoDB
    similar_events = mongo_manager.get_similar_events(
        event_data.get('source_ip', ''),
        event_data.get('event_type', ''),
        limit=3
    )
    
    if similar_events:
        event_data['mongodb_similar_events'] = similar_events
        print(f"Found {len(similar_events)} similar events in MongoDB")
    
    return {
        'event_id': event_id,
        'event_data': event_data,
        'messages': state['messages']
    }

def check_cache(state: state_reasoning_agent):
    """Check if similar event exists in cache"""
    event_data = state['event_data']
    cached_result = cache.search_similar_events(event_data)
    
    if cached_result:
        print(f"Found similar event with {cached_result['similarity_score']:.2f} similarity")
        print(f"Using cached response from {cached_result['original_timestamp']}")
        return {
            'cached_response': cached_result['cached_response'],
            'messages': state['messages'],
            'event_id': state['event_id']
        }
    
    return {
        'cached_response': None,
        'messages': state['messages'],
        'event_id': state['event_id']
    }

def reasoner(state: state_reasoning_agent):
    """Process the event with LLM if not cached"""
    if state.get('cached_response'):
        # Return cached response
        return {
            'messages': state['messages'],
            'cached_response': state['cached_response'],
            'event_id': state['event_id']
        }
    
    # Format the prompt with event data
    event_data = state['event_data']
    event_type_prompt = event_data.get('event_type', '')
    formatted_prompt = prompt_template.format(
        event_type_prompt=event_type_prompt,
        event_data=json.dumps(event_data, indent=2)
    )
    
    # Create human message with the formatted prompt
    human_message = HumanMessage(content=formatted_prompt)
    
    try:
        # Get LLM response
        response = llm.invoke([human_message])
        response_content = response.content
        
        # Store in cache
        cache.store_event_response(event_data, response_content)
        
        # Parse the JSON response
        parsed_response = json.loads(response_content)
        return {
            'messages': [response],
            'llm_response': parsed_response,
            'event_id': state['event_id']
        }
    except json.JSONDecodeError as e:
        print(f"JSON parsing error: {e}")
        return {
            'messages': [],
            'llm_response': {
                'error': 'Failed to parse JSON response', 
                'raw_response': response_content if 'response_content' in locals() else 'No response'
            },
            'event_id': state['event_id']
        }
    except Exception as e:
        print(f"LLM invocation error: {e}")
        return {
            'messages': [],
            'llm_response': {'error': f'LLM error: {str(e)}'},
            'event_id': state['event_id']
        }

def output_formatter(state: state_reasoning_agent):
    """Format the final output and store analysis in MongoDB"""
    event_id = state['event_id']
    
    if state.get('cached_response'):
        analysis_result = state['cached_response']
        source = 'cache'
    else:
        analysis_result = state.get('llm_response')
        source = 'llm'
    
    # Store analysis in MongoDB
    if event_id and analysis_result and 'error' not in analysis_result:
        mongo_manager.store_analysis(event_id, analysis_result, source)
    
    return {
        'final_output': {
            'event_id': event_id,
            'source': source,
            'response': analysis_result
        }
    }

# Build the graph
graph_builder = StateGraph(state_reasoning_agent)

graph_builder.add_node("store_event", store_event_node)
graph_builder.add_node("check_cache", check_cache)
graph_builder.add_node("reasoner", reasoner)
graph_builder.add_node("output_formatter", output_formatter)

graph_builder.add_edge(START, "store_event")
graph_builder.add_edge("store_event", "check_cache")
graph_builder.add_edge("check_cache", "reasoner")
graph_builder.add_edge("reasoner", "output_formatter")
graph_builder.add_edge("output_formatter", END)

reasoning_agent = graph_builder.compile()

# Example usage
if __name__ == "__main__":
    # Sample input data
    reco_agent_input = {
        "event_type": "brute_force_login_attempt",
        "timestamp": "2025-08-31T13:55:12Z",
        "source_ip": "203.0.113.45",
        "destination": "login.corpplatform.com",
        "username": "admin",
        "success": False,
        "failure_count": 25,
        "payload": "password: !admin@123",
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "anomaly_score": 0.92,
        "session_id": "xyzabc98765",
        "detection_confidence": 0.98,
        "historical_events": [
            {
                "timestamp": "2025-08-31T13:54:05Z",
                "source_ip": "203.0.113.45",
                "failure_count": 15,
                "session_id": "xyzabc98765"
            }
        ],
        "asset_criticality": "high",
        "remediation_action": "none"
    }

    try:
        # Run the reasoning agent
        response = reasoning_agent.invoke({
            'messages': [],
            'event_data': reco_agent_input,
            'event_id': None
        })

        print("\n=== SECURITY EVENT ANALYSIS RESULT ===")
        print(json.dumps(response.get('final_output'), indent=2))
        
        # Display statistics
        print("\n=== MONGODB STATISTICS ===")
        stats = mongo_manager.get_statistics()
        print(json.dumps(stats, indent=2))
        
    except Exception as e:
        print(f"Error running reasoning agent: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Close MongoDB connection
        mongo_client.close()