import json
import time
import uuid
import re
import os
from datetime import datetime
from collections import deque
import subprocess
import sys
from typing import Dict, List, Optional, Any

# LangChain and LangSmith imports
from langchain_ollama import OllamaLLM
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langsmith import Client
import langsmith

class AegisMindLangChainDemo:
    """
    AegisMind with LangChain-Ollama and LangSmith Integration
    Advanced AI cybersecurity analysis with monitoring and observability
    """
    
    def __init__(self, model_name: str = "hf.co/AlicanKiraz0/Cybersecurity-BaronLLM_Offensive_Security_LLM_Q6_K_GGUF:Q6_K"):
        self.model_name = model_name
        self.ollama_url = "http://localhost:11434"
        self.analysis_history = deque(maxlen=50)
        self.model_ready = False
        
        # LangSmith configuration
        self._setup_langsmith()
        
        # Initialize LangChain components
        self.llm = None
        self.analysis_chain = None
        
        print("🚀 AegisMind LangChain-Ollama with LangSmith Integration")
        print("=" * 60)
        
        # Setup LangChain-Ollama
        self._setup_langchain_ollama()
        
        # Test scenarios
        self.test_scenarios = self._create_test_scenarios()
    
    def _setup_langsmith(self):
        """Configure LangSmith for monitoring and observability"""
        try:
            # Set LangSmith environment variables
            os.environ["LANGSMITH_API_KEY"] = "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"
            os.environ["LANGSMITH_PROJECT"] = "Text Translation"
            os.environ["LANGSMITH_ENDPOINT"] = "https://api.smith.langchain.com"
            os.environ["LANGSMITH_TRACING"] = "true"
            
            # Initialize LangSmith client
            self.langsmith_client = Client(
                api_key=os.environ["LANGSMITH_API_KEY"],
                api_url=os.environ["LANGSMITH_ENDPOINT"]
            )
            
            print("✅ LangSmith configured successfully")
            print(f"   📊 Project: {os.environ['LANGSMITH_PROJECT']}")
            print(f"   🔗 Endpoint: {os.environ['LANGSMITH_ENDPOINT']}")
            
            # Test LangSmith connection
            try:
                # Get project info to verify connection
                projects = list(self.langsmith_client.list_projects(limit=1))
                print("✅ LangSmith connection verified")
            except Exception as e:
                print(f"⚠️ LangSmith connection issue: {e}")
            
        except Exception as e:
            print(f"⚠️ LangSmith setup failed: {e}")
            print("   Continuing without LangSmith monitoring...")
    
    def _check_ollama_service(self):
        """Check if Ollama service is running"""
        try:
            import requests
            response = requests.get(f"{self.ollama_url}/api/version", timeout=5)
            if response.status_code == 200:
                version_info = response.json()
                print(f"✅ Ollama service running: v{version_info.get('version', 'unknown')}")
                return True
            else:
                print(f"❌ Ollama service responded with status {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Cannot connect to Ollama service: {e}")
            print("💡 Make sure Ollama is running: 'ollama serve'")
            return False
    
    def _pull_model_if_needed(self):
        """Pull model if not available"""
        try:
            # Check if model exists
            result = subprocess.run(
                ['ollama', 'list'], 
                capture_output=True, 
                text=True, 
                check=True
            )
            
            if self.model_name not in result.stdout:
                print(f"📥 Pulling model: {self.model_name}")
                print("⏳ This may take several minutes...")
                
                pull_result = subprocess.run(
                    ['ollama', 'pull', self.model_name],
                    check=True
                )
                
                if pull_result.returncode == 0:
                    print(f"✅ Model {self.model_name} pulled successfully!")
                    return True
                else:
                    print(f"❌ Failed to pull model {self.model_name}")
                    return False
            else:
                print(f"✅ Model {self.model_name} already available")
                return True
                
        except subprocess.CalledProcessError as e:
            print(f"❌ Error with ollama command: {e}")
            return False
        except FileNotFoundError:
            print("❌ Ollama not found. Please install Ollama first.")
            return False
    
    def _setup_langchain_ollama(self):
        """Setup LangChain-Ollama integration"""
        try:
            # Check Ollama service
            if not self._check_ollama_service():
                print("❌ Ollama service not available")
                return
            
            # Pull model if needed
            if not self._pull_model_if_needed():
                print("❌ Model not available")
                return
            
            # Initialize LangChain-Ollama LLM
            print("🔗 Initializing LangChain-Ollama...")
            
            self.llm = OllamaLLM(
                model=self.model_name,
                base_url=self.ollama_url,
                temperature=0.1,
                top_p=0.9,
                top_k=40,
                num_predict=500,
                stop=["Human:", "Assistant:", "\n\nHuman:", "\n\nAssistant:"]
            )
            
            # Create analysis prompt template
            self.analysis_prompt = PromptTemplate(
                input_variables=["source_ip", "url", "method", "user_agent", "payload"],
                template="""You are an expert cybersecurity analyst specializing in attack detection and analysis.

REQUEST DETAILS:
- Source IP: {source_ip}
- URL: {url}
- Method: {method}
- User-Agent: {user_agent}
- Payload: {payload}

ANALYSIS TASKS:
1. Determine if this is a genuine security attack
2. Classify the attack type and technique
3. Assess threat level and sophistication
4. Identify any penetration testing tools
5. Recommend immediate response actions

RESPONSE FORMAT (be precise and structured):
Threat Level: [CRITICAL/HIGH/MEDIUM/LOW]
Attack Type: [SQL_INJECTION/XSS/COMMAND_INJECTION/PATH_TRAVERSAL/etc]
Technique: [Specific technique or vector used]
Sophistication: [SCRIPT_KIDDIE/INTERMEDIATE/ADVANCED/APT]
Confidence: [0.0-1.0 numeric confidence score]
Tools Detected: [Comma-separated list of detected tools]
Immediate Actions: [Comma-separated response actions]
Analysis: [Detailed technical explanation of the attack]

Begin your cybersecurity analysis:"""
            )
            
            # Create analysis chain with LangSmith tracing
            self.analysis_chain = (
                self.analysis_prompt 
                | self.llm 
                | StrOutputParser()
            )
            
            print("✅ LangChain-Ollama initialized successfully")
            
            # Test the setup
            self.model_ready = self._test_langchain_setup()
            
        except Exception as e:
            print(f"❌ LangChain-Ollama setup failed: {e}")
            self.model_ready = False
    
    def _test_langchain_setup(self):
        """Test LangChain-Ollama setup"""
        try:
            print("\n🧪 Testing LangChain-Ollama setup...")
            
            test_input = {
                "source_ip": "192.168.1.100",
                "url": "/test",
                "method": "GET",
                "user_agent": "Test Agent",
                "payload": "admin' OR 1=1--"
            }
            
            with langsmith.trace(name="setup_test", project_name="Text Translation"):
                response = self.analysis_chain.invoke(test_input)
            
            if response and response.strip():
                print(f"✅ LangChain test successful: {response[:100]}...")
                return True
            else:
                print("⚠️ LangChain test returned empty response")
                return False
                
        except Exception as e:
            print(f"⚠️ LangChain test failed: {e}")
            return False
    
    def analyze_with_ai(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze security event using LangChain-Ollama with LangSmith monitoring"""
        
        if not self.model_ready:
            return self._fallback_analysis(request_data)
        
        try:
            # Prepare input for LangChain
            chain_input = {
                "source_ip": request_data.get("source_ip", "unknown"),
                "url": request_data.get("url", ""),
                "method": request_data.get("method", "GET"),
                "user_agent": request_data.get("user_agent", ""),
                "payload": request_data.get("payload", "")
            }
            
            # Create metadata for LangSmith
            metadata = {
                "attack_scenario": request_data.get("scenario_name", "unknown"),
                "source_ip": chain_input["source_ip"],
                "model_name": self.model_name,
                "analysis_type": "cybersecurity_threat_detection"
            }
            
            # Run analysis with LangSmith tracing
            start_time = time.time()
            
            with langsmith.trace(
                name="cybersecurity_analysis",
                project_name="Text Translation",
                metadata=metadata,
                tags=["cybersecurity", "threat-detection", "ollama"]
            ) as trace:
                ai_response = self.analysis_chain.invoke(chain_input)
                analysis_time = round((time.time() - start_time) * 1000, 2)
                
                # Add metrics to trace
                trace.metadata.update({
                    "analysis_time_ms": analysis_time,
                    "response_length": len(ai_response) if ai_response else 0
                })
            
            if ai_response:
                # Parse AI response
                parsed = self._parse_ai_response(ai_response)
                
                # Log to LangSmith
                self._log_to_langsmith(chain_input, ai_response, parsed, analysis_time)
                
                return {
                    "analysis_id": str(uuid.uuid4()),
                    "timestamp": datetime.now().isoformat(),
                    "model_used": f"{self.model_name} (LangChain-Ollama)",
                    "ai_analysis_time_ms": analysis_time,
                    "request_summary": {
                        "source_ip": chain_input["source_ip"],
                        "url": chain_input["url"],
                        "method": chain_input["method"],
                        "user_agent": chain_input["user_agent"]
                    },
                    "ai_assessment": parsed,
                    "raw_ai_response": ai_response,
                    "langsmith_trace": True,
                    "success": True
                }
            else:
                return self._fallback_analysis(request_data)
                
        except Exception as e:
            print(f"⚠️ AI analysis failed: {e}")
            return self._fallback_analysis(request_data)
    
    def _log_to_langsmith(self, input_data: Dict, response: str, parsed: Dict, analysis_time: float):
        """Log analysis results to LangSmith"""
        try:
            # Create a run for logging
            with langsmith.trace(
                name="analysis_result_logging",
                project_name="Text Translation",
                metadata={
                    "threat_level": parsed.get("threat_level"),
                    "attack_type": parsed.get("attack_type"),
                    "confidence": parsed.get("confidence"),
                    "analysis_time_ms": analysis_time,
                    "parsing_success": parsed.get("parsing_success", False)
                },
                tags=["result-logging", "metrics"]
            ):
                # Log key metrics
                print(f"📊 LangSmith logged: {parsed.get('attack_type')} - {parsed.get('threat_level')}")
                
        except Exception as e:
            print(f"⚠️ LangSmith logging failed: {e}")
    
    def _parse_ai_response(self, ai_response: str) -> Dict[str, Any]:
        """Parse AI response into structured format"""
        
        try:
            # Extract fields using regex
            threat_level = self._extract_field(ai_response, r"Threat Level:\s*(\w+)")
            attack_type = self._extract_field(ai_response, r"Attack Type:\s*([^\n]+)")
            technique = self._extract_field(ai_response, r"Technique:\s*([^\n]+)")
            sophistication = self._extract_field(ai_response, r"Sophistication:\s*(\w+)")
            confidence = self._extract_field(ai_response, r"Confidence:\s*([\d.]+)")
            tools = self._extract_field(ai_response, r"Tools Detected:\s*([^\n]+)")
            actions = self._extract_field(ai_response, r"Immediate Actions:\s*([^\n]+)")
            analysis = self._extract_field(ai_response, r"Analysis:\s*([^\n]+)")
            
            return {
                "threat_level": threat_level or "MEDIUM",
                "attack_type": attack_type or "UNKNOWN",
                "technique": technique or "Unknown technique",
                "sophistication": sophistication or "INTERMEDIATE",
                "confidence": float(confidence) if confidence else 0.7,
                "tools_detected": tools.split(", ") if tools else [],
                "immediate_actions": actions.split(", ") if actions else [],
                "analysis": analysis or "AI analysis completed",
                "parsing_success": True
            }
            
        except Exception as e:
            return {
                "threat_level": "MEDIUM",
                "attack_type": "PARSING_ERROR",
                "confidence": 0.5,
                "analysis": f"Failed to parse AI response: {str(e)}",
                "raw_response": ai_response,
                "parsing_success": False
            }
    
    def _extract_field(self, text: str, pattern: str) -> Optional[str]:
        """Extract field from AI response"""
        try:
            match = re.search(pattern, text, re.IGNORECASE)
            return match.group(1).strip() if match else None
        except:
            return None
    
    def _fallback_analysis(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback analysis when AI is not available"""
        
        payload = request_data.get("payload", "")
        
        # Simple pattern-based analysis
        if any(pattern in payload.lower() for pattern in ["union", "select", "or 1=1"]):
            attack_type = "SQL_INJECTION"
            threat_level = "HIGH"
        elif any(pattern in payload.lower() for pattern in ["<script>", "javascript:", "alert("]):
            attack_type = "XSS"
            threat_level = "MEDIUM"
        elif any(pattern in payload.lower() for pattern in [";", "|", "cat ", "ls "]):
            attack_type = "COMMAND_INJECTION"
            threat_level = "CRITICAL"
        else:
            attack_type = "UNKNOWN"
            threat_level = "LOW"
        
        return {
            "analysis_id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "model_used": "Pattern-based fallback",
            "ai_analysis_time_ms": 5,
            "ai_assessment": {
                "threat_level": threat_level,
                "attack_type": attack_type,
                "confidence": 0.6,
                "analysis": f"Pattern-based detection: {attack_type}",
                "fallback_used": True
            },
            "success": True
        }
    
    def _create_test_scenarios(self) -> List[Dict[str, Any]]:
        """Create test attack scenarios for demonstration"""
        return [
            {
                "name": "SQL Injection - Union Based",
                "request": {
                    "source_ip": "192.168.1.100",
                    "url": "/login?username=admin' UNION SELECT password FROM users--&password=test",
                    "method": "GET",
                    "user_agent": "Mozilla/5.0",
                    "payload": "admin' UNION SELECT password FROM users--",
                    "scenario_name": "sql_injection_union"
                },
                "expected": "Critical SQL injection with union-based technique"
            },
            {
                "name": "SQL Injection - Boolean Blind",
                "request": {
                    "source_ip": "203.0.113.45",
                    "url": "/login",
                    "method": "POST",
                    "user_agent": "python-requests/2.25.1",
                    "payload": "username=admin' AND 1=1--&password=test",
                    "scenario_name": "sql_injection_blind"
                },
                "expected": "Boolean-based blind SQL injection"
            },
            {
                "name": "XSS Attack - Reflected",
                "request": {
                    "source_ip": "172.16.0.50",
                    "url": "/search?q=<script>alert('XSS')</script>",
                    "method": "GET",
                    "user_agent": "Mozilla/5.0",
                    "payload": "<script>alert('XSS')</script>",
                    "scenario_name": "xss_reflected"
                },
                "expected": "Cross-site scripting attack"
            },
            {
                "name": "Command Injection",
                "request": {
                    "source_ip": "198.51.100.75",
                    "url": "/exec",
                    "method": "POST",
                    "user_agent": "curl/7.68.0",
                    "payload": "command=ls; cat /etc/passwd",
                    "scenario_name": "command_injection"
                },
                "expected": "Command injection attempt"
            },
            {
                "name": "SQL Injection - Time Based",
                "request": {
                    "source_ip": "10.0.0.5",
                    "url": "/search",
                    "method": "GET",
                    "user_agent": "sqlmap/1.6.12",
                    "payload": "q=test' AND sleep(5)--",
                    "scenario_name": "sql_injection_time"
                },
                "expected": "Time-based SQL injection"
            }
        ]
    
    def run_demo_tests(self):
        """Run all demo test scenarios with LangSmith monitoring"""
        
        print("\n🎯 Running AegisMind AI Demo Tests with LangSmith")
        print("=" * 60)
        
        if not self.model_ready:
            print("❌ Model not ready. Cannot run tests.")
            return
        
        for i, scenario in enumerate(self.test_scenarios, 1):
            print(f"\n🧪 Test {i}: {scenario['name']}")
            print("-" * 40)
            
            # Analyze with AI and LangSmith monitoring
            result = self.analyze_with_ai(scenario["request"])
            
            # Display results
            print(f"🎯 Source IP: {result['request_summary']['source_ip']}")
            print(f"🌐 URL: {result['request_summary']['url'][:50]}...")
            print(f"🕐 Analysis Time: {result['ai_analysis_time_ms']}ms")
            print(f"🤖 Model: {result['model_used']}")
            print(f"📊 LangSmith Traced: {result.get('langsmith_trace', False)}")
            
            assessment = result["ai_assessment"]
            print(f"\n📊 AI Assessment:")
            print(f"   ⚡ Threat Level: {assessment['threat_level']}")
            print(f"   🎪 Attack Type: {assessment['attack_type']}")
            print(f"   🎯 Confidence: {assessment['confidence']:.2f}")
            print(f"   🧠 Analysis: {assessment['analysis']}")
            
            if assessment.get("technique"):
                print(f"   🛠️  Technique: {assessment['technique']}")
            if assessment.get("tools_detected"):
                print(f"   🔧 Tools: {assessment['tools_detected']}")
            if assessment.get("immediate_actions"):
                print(f"   💡 Actions: {assessment['immediate_actions']}")
            
            # Store result
            self.analysis_history.append(result)
            
            time.sleep(1)  # Brief pause between tests
        
        print(f"\n✅ Demo Complete! Analyzed {len(self.test_scenarios)} attack scenarios")
        print("📊 Check LangSmith dashboard for detailed traces and metrics")
        self._show_summary()
    
    def _show_summary(self):
        """Show summary of all analyses"""
        
        print("\n📊 Demo Summary")
        print("=" * 40)
        
        if not self.analysis_history:
            print("No analyses performed")
            return
        
        threat_levels = {}
        attack_types = {}
        avg_time = 0
        avg_confidence = 0
        langsmith_traces = 0
        
        for analysis in self.analysis_history:
            # Threat levels
            level = analysis["ai_assessment"]["threat_level"]
            threat_levels[level] = threat_levels.get(level, 0) + 1
            
            # Attack types
            attack_type = analysis["ai_assessment"]["attack_type"]
            attack_types[attack_type] = attack_types.get(attack_type, 0) + 1
            
            # Average metrics
            avg_time += analysis["ai_analysis_time_ms"]
            avg_confidence += analysis["ai_assessment"]["confidence"]
            
            # LangSmith traces
            if analysis.get("langsmith_trace"):
                langsmith_traces += 1
        
        count = len(self.analysis_history)
        avg_time /= count
        avg_confidence /= count
        
        print(f"📈 Total Analyses: {count}")
        print(f"⏱️  Average Analysis Time: {avg_time:.1f}ms")
        print(f"🎯 Average Confidence: {avg_confidence:.2f}")
        print(f"📊 LangSmith Traces: {langsmith_traces}/{count}")
        print(f"🚨 Threat Levels: {threat_levels}")
        print(f"🎪 Attack Types: {attack_types}")
        print(f"🤖 Model: {self.model_name}")
        print(f"🔗 LangSmith Project: {os.environ.get('LANGSMITH_PROJECT', 'N/A')}")
    
    def test_custom_attack(self, payload: str, scenario_name: str = "custom_test"):
        """Test custom attack payload with LangSmith monitoring"""
        
        print(f"\n🔍 Testing Custom Payload: {payload}")
        
        custom_request = {
            "source_ip": "127.0.0.1",
            "url": f"/test?payload={payload}",
            "method": "GET",
            "user_agent": "Custom Test Agent",
            "payload": payload,
            "scenario_name": scenario_name
        }
        
        result = self.analyze_with_ai(custom_request)
        
        print(f"📊 AI Analysis Result:")
        assessment = result["ai_assessment"]
        print(f"   Threat Level: {assessment['threat_level']}")
        print(f"   Attack Type: {assessment['attack_type']}")
        print(f"   Confidence: {assessment['confidence']:.2f}")
        print(f"   Analysis: {assessment['analysis']}")
        print(f"   LangSmith Traced: {result.get('langsmith_trace', False)}")
        
        return result
    
    def get_langsmith_metrics(self):
        """Get metrics from LangSmith"""
        try:
            # This would require additional LangSmith SDK methods
            # For now, just print the project info
            print(f"📊 LangSmith Project: {os.environ.get('LANGSMITH_PROJECT')}")
            print(f"🔗 Dashboard: https://smith.langchain.com/projects")
            return {"project": os.environ.get('LANGSMITH_PROJECT')}
        except Exception as e:
            print(f"⚠️ Could not retrieve LangSmith metrics: {e}")
            return None

# LangChain-Ollama Demo Runner
def run_langchain_demo():
    """Run the complete LangChain-Ollama demo with LangSmith"""
    
    print("🚀 AegisMind LangChain-Ollama + LangSmith Demo Starting...")
    
    # Initialize demo
    demo = AegisMindLangChainDemo()
    
    if not demo.model_ready:
        print("❌ Cannot proceed without a working model")
        print("\n💡 Setup Instructions:")
        print("1. Install Ollama: curl -fsSL https://ollama.ai/install.sh | sh")
        print("2. Start Ollama: ollama serve")
        print("3. Pull model: ollama pull AlicanKiraz0/Cybersecurity-BaronLLM_Offensive_Security_LLM_Q6_K_GGUF")
        print("4. Run this script again")
        return None
    
    # Run predefined tests
    demo.run_demo_tests()
    
    # Test custom payloads
    print("\n🔧 Testing Custom Payloads with LangSmith:")
    custom_tests = [
        ("admin' OR 1=1--", "sql_injection_custom"),
        ("<script>alert('langsmith-test')</script>", "xss_custom"),
        ("'; cat /etc/passwd", "command_injection_custom"),
        ("test' UNION SELECT password FROM users--", "sql_union_custom")
    ]
    
    for payload, scenario_name in custom_tests:
        demo.test_custom_attack(payload, scenario_name)
        time.sleep(0.5)
    
    # Show LangSmith info
    print("\n📊 LangSmith Integration:")
    demo.get_langsmith_metrics()
    
    print("\n✅ LangChain-Ollama + LangSmith Demo Complete!")
    print("🎯 All interactions tracked in LangSmith for analysis!")
    print("🔗 Visit https://smith.langchain.com to view traces and metrics")
    
    return demo

# Run the demo
if __name__ == "__main__":
    demo = run_langchain_demo()
    
    if demo:
        print("\n💡 Demo object available for manual testing:")
        print("   demo.test_custom_attack('your payload', 'scenario_name')")
        print("   demo.get_langsmith_metrics()")